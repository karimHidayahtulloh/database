/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import connection.connection;

/**
 *
 * @author USER
 */
public class muser {

    private Statement stm;
    private ResultSet rs;
    private String jobs, nama;
    connection konek;

    public muser() throws SQLException {
        this.konek = new connection();
    }
// koneksi cn = new koneksi();
//        ResultSet data = cn.getResult("select * from public.data_user;");
//        System.out.println(data.getRow());
//        while(data.next()){
//            System.out.println(data.getString(3)+data.getString(4));

    public void inputNama(String User_name, String Password) {
        try {
            String query = "insert into user_name from db_game_si.user";
//            "username" nama tabel, dan "db_game_si" nama skemanya
            stm = konek.getConnection().createStatement();
            rs = stm.executeQuery(query);
        } catch (SQLException e) {
            System.out.println("Error : " + e);
        }
    }
}
